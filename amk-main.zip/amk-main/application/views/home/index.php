<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12">
                <div class="bootstrap-carousel">
                    <div data-ride="carousel" class="carousel slide" id="carouselExampleCaptions">
                        <ol class="carousel-indicators">
                            <li class="active" data-slide-to="0" data-target="#carouselExampleCaptions">
                            </li>
                            <li data-slide-to="1" data-target="#carouselExampleCaptions" class=""></li>
                            <li data-slide-to="2" data-target="#carouselExampleCaptions" class=""></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="d-block w-100" src="<?= base_url('assets/type1.jpg'); ?>" alt="">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5>Tipe 36</h5>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img alt="" class="d-block w-100" src="<?= base_url('assets/type2.jpg'); ?>">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5>Tipe 37</h5>
                                </div>
                            </div>

                        </div><a data-slide="prev" href="#carouselExampleCaptions" class="carousel-control-prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span>
                        </a><a data-slide="next" href="#carouselExampleCaptions" class="carousel-control-next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<!--**********************************
            Content body end
        ***********************************-->