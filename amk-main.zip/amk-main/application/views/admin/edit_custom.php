<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="basic-form">
                            <div class="card-body">
                                <div class="basic-form custom_file_input">
                                    <form action="<?= base_url('administrator/save_editcustom/') . $custom['id']; ?>" method="POST" enctype="multipart/form-data">
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <input type="text" name="custom" class="form-control form-control-sm" placeholder="Custom" value="<?= $custom['custom']; ?>">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <textarea type="text" name="deskripsi" class="form-control form-control-sm" placeholder="Deskripsi"><?= $custom['deskripsi']; ?></textarea>
                                            </div>
                                        </div>

                                        <div class="input-group mb-3">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" name="image" id="image" required>
                                                <label class="custom-file-label">Choose</label>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <input type="text" name="harga" class="form-control form-control-sm" placeholder="Harga" value="<?= $custom['harga']; ?>">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>
<!--**********************************
            Content body end
        ***********************************-->

<script src="<?= base_url('assets/js/jquery-3.6.0.js'); ?>"></script>
<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>